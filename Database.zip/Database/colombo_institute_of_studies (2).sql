-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2023 at 06:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `colombo_institute_of_studies`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `Dept_Name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`Dept_Name`) VALUES
('Academic'),
('HR'),
('IT');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `Dept_ID` varchar(20) NOT NULL,
  `Dept_Name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`Dept_ID`, `Dept_Name`) VALUES
('001', 'Human Reasouses'),
('002', 'IT'),
('003', 'Academic'),
('004', 'Bussienss Management'),
('005', 'Marketing'),
('006', 'Cleaning'),
('007', 'Financial');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `ID` int(10) NOT NULL,
  `Name` varchar(30) DEFAULT NULL,
  `Department` varchar(20) DEFAULT NULL,
  `Designation` varchar(20) DEFAULT NULL,
  `EPF_Number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`ID`, `Name`, `Department`, `Designation`, `EPF_Number`) VALUES
(1, 'Ushan', 'Human Reasouce', 'HR executive', 'MWM202133'),
(2, 'emil', 'IT', 'Assistance', 'MW1567'),
(3, 'Pamoda', 'IT', 'Lecturer', 'MK4454H354'),
(4, 'Ushan', 'Human Reasouce', 'HR executive', 'MWM202133'),
(5, 'Keshan', 'IT', 'IT Administrator', 'ME2456F566'),
(6, 'Linuka', 'IT', 'Lecturer', 'MW248465');

-- --------------------------------------------------------

--
-- Table structure for table `job tittle`
--

CREATE TABLE `job tittle` (
  `Job_title` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_ID` varchar(10) NOT NULL,
  `user_Name` varchar(30) NOT NULL,
  `user_Pass` varchar(20) NOT NULL,
  `user_Role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_ID`, `user_Name`, `user_Pass`, `user_Role`) VALUES
('A1', 'admin', 'admin', 'Admin'),
('A2', 'HR Manager', 'HR Manager', 'Manager'),
('A3', 'HR Assistant', 'HR Assistant', 'Assistance');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`Dept_Name`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`Dept_ID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `job tittle`
--
ALTER TABLE `job tittle`
  ADD PRIMARY KEY (`Job_title`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
